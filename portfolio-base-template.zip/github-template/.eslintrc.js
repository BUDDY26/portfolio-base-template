module.exports = {
  root: true,
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: "module",
    project: "./tsconfig.json",
  },
  plugins: ["@typescript-eslint"],
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:@typescript-eslint/recommended-requiring-type-checking",
    "prettier", // must be last — disables ESLint rules that conflict with Prettier
  ],
  rules: {
    // Enforce explicit return types on functions
    "@typescript-eslint/explicit-function-return-type": "warn",
    // Disallow any
    "@typescript-eslint/no-explicit-any": "error",
    // Require await on async functions
    "@typescript-eslint/require-await": "error",
    // No unused variables (TypeScript handles this with noUnusedLocals too)
    "@typescript-eslint/no-unused-vars": ["error", { argsIgnorePattern: "^_" }],
    // No console.log in production code (use proper logger)
    "no-console": "warn",
  },
  ignorePatterns: ["dist/", "node_modules/", "jest.config.js", "*.js"],
};
