# {{PROJECT_NAME}}

> {{PROJECT_DESCRIPTION}}

<!--
  ┌─────────────────────────────────────────────────────────┐
  │  This repository was created from the portfolio-base    │
  │  template. Replace all {{PLACEHOLDER}} values before    │
  │  your first commit. Run scripts/bootstrap.sh to do      │
  │  this automatically.                                     │
  └─────────────────────────────────────────────────────────┘
-->

## Overview

{{PROJECT_OVERVIEW}}

## Features

- {{FEATURE_1}}
- {{FEATURE_2}}
- {{FEATURE_3}}

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | {{LANGUAGE}} |
| Framework | {{FRAMEWORK}} |
| Database | {{DATABASE}} |
| Testing | {{TEST_FRAMEWORK}} |

## Getting Started

### Prerequisites

- {{PREREQ_1}}
- {{PREREQ_2}}

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/{{GITHUB_USERNAME}}/{{REPO_NAME}}.git
cd {{REPO_NAME}}

# 2. Run the bootstrap script to finish setup
bash scripts/bootstrap.sh

# 3. Install dependencies
{{INSTALL_COMMAND}}

# 4. Configure environment
cp .env.example .env
# Edit .env — see docs/runbooks/operations.md for all required values
```

### Running the Application

```bash
{{RUN_COMMAND}}
```

### Running Tests

```bash
{{TEST_COMMAND}}
```

## Project Structure

```
{{REPO_NAME}}/
├── CLAUDE.md                    # Claude Code operating guide
├── README.md                    # This file
├── .env.example                 # Environment variable reference
├── .gitignore
│
├── src/                         # Application source code
│   └── CLAUDE.md                # Module-level sharp-edge notes
│
├── tests/                       # All test files
│   ├── unit/
│   └── integration/
│
├── docs/                        # Architecture and process documentation
│   ├── architecture.md
│   ├── adr/                     # Architecture Decision Records
│   ├── qa/
│   └── runbooks/
│
├── scripts/                     # Automation scripts
│   ├── bootstrap.sh             # First-time setup
│   └── validate-structure.sh   # Verify repo structure
│
└── .claude/                     # Claude Code configuration
    ├── skills/                  # Reusable expert workflows
    └── hooks/                   # Automatic guardrails
```

## Architecture

{{ARCHITECTURE_SUMMARY}}

Full system design is documented in [docs/architecture.md](docs/architecture.md).

## Key Technical Decisions

Architectural decisions are documented in [docs/adr/](docs/adr/).

## Using This Template

This repository was created from [portfolio-base](https://github.com/{{GITHUB_USERNAME}}/portfolio-base). To apply the same structure to a new project:

1. Go to the template repository on GitHub
2. Click **Use this template → Create a new repository**
3. Clone your new repo and run `bash scripts/bootstrap.sh`

## License

{{LICENSE}}

---

*Built and maintained as part of a professional software engineering portfolio.*  
*Reviewed for UT Austin MSCS graduate admissions and software engineering employer review.*
