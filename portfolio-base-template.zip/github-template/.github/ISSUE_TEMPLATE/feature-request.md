---
name: Feature Request
about: Propose a new feature or improvement
title: "feat: [brief description]"
labels: ["enhancement", "needs-triage"]
assignees: ""
---

## Problem Statement

<!-- What problem does this feature solve? Why is it needed? -->

## Proposed Solution

<!-- Describe the feature you'd like. Be specific about behavior and interface. -->

## Alternatives Considered

<!-- What other approaches did you consider? Why did you choose this one? -->

## Acceptance Criteria

<!-- How will we know this feature is complete and working? List testable conditions. -->

- [ ] [Condition 1]
- [ ] [Condition 2]
- [ ] [Condition 3]

## Additional Context

<!-- Mockups, diagrams, related issues, or links to prior art -->

## Implementation Notes

<!-- Any technical constraints or suggestions. Not required. -->

## Portfolio Value

<!-- For portfolio repositories: what does implementing this feature demonstrate? -->
