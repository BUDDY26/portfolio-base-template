---
name: Bug Report
about: Report a reproducible bug or unexpected behavior
title: "bug: [brief description]"
labels: ["bug", "needs-triage"]
assignees: ""
---

## Bug Description

<!-- A clear and concise description of the bug -->

## Steps to Reproduce

1. [First step]
2. [Second step]
3. [...]

## Expected Behavior

<!-- What you expected to happen -->

## Actual Behavior

<!-- What actually happened. Include error messages, tracebacks, or screenshots. -->

```
[Paste error output here]
```

## Environment

- OS: [e.g., macOS 14, Ubuntu 22.04]
- Language version: [e.g., Python 3.11.6]
- Dependency versions: [e.g., run `pip freeze | grep relevant-package`]
- Branch / commit: [e.g., `main` at `abc1234`]

## Minimal Reproducible Example

<!-- The smallest possible code snippet that reproduces the issue -->

```python
# Paste minimal reproduction here
```

## Additional Context

<!-- Any other information that might be relevant -->

## Possible Fix

<!-- If you have a hypothesis about the cause, note it here. Not required. -->
