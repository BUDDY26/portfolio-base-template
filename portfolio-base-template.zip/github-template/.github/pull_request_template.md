## Summary

<!-- What does this PR do? One paragraph. -->

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that changes existing behavior)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)
- [ ] CI/CD or tooling update

## Related Issues

<!-- Link issues this PR closes or relates to -->
Closes #

## Changes Made

<!-- List the specific files and changes. Be precise. -->

- `src/[file]`: [what changed and why]
- `tests/[file]`: [what was tested]
- `docs/[file]`: [what was documented]

## Testing

- [ ] I ran the full test suite locally: `{{TEST_COMMAND}}`
- [ ] All existing tests pass
- [ ] New tests were added for new functionality
- [ ] Edge cases are covered

**Test coverage change:** [increased / maintained / decreased — explain if decreased]

## Documentation

- [ ] CLAUDE.md updated if architecture or rules changed
- [ ] README.md updated if setup or usage changed
- [ ] Docstrings added/updated for new/changed functions
- [ ] ADR created for any significant architectural decision made in this PR

## Quality Checklist

- [ ] No hardcoded secrets, credentials, or API keys
- [ ] No `print()` / `console.log()` debug statements left in production paths
- [ ] No commented-out code blocks left in
- [ ] Function names and variables are descriptive
- [ ] Functions are under 30 lines (or justified if longer)
- [ ] Linter passes: `{{LINT_COMMAND}}`

## Portfolio Note

<!-- If this is a portfolio repository, note what this PR demonstrates -->
**Demonstrates:** [e.g., error handling pattern, async processing, test-driven development]

---

> Reviewed by Claude using `.claude/skills/code-review.md` before submission: [ ] yes / [ ] no
