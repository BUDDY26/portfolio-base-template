# ADR-001: [Decision Title]

**Date:** {{LAST_UPDATED}}
**Status:** Accepted
**Deciders:** {{GITHUB_USERNAME}}

---

## Context

[What situation or problem required a decision? What constraints existed?
Be specific — include technical constraints, timeline, and available options.]

---

## Decision

**We decided to:** [state the decision in one clear sentence]

---

## Rationale

[Why was this option chosen? What were the most important factors?
What would have broken or been harder with the alternatives?]

---

## Alternatives Considered

| Option | Pros | Cons | Why Not Chosen |
|--------|------|------|----------------|
| [Option A — chosen] | [pros] | [cons] | *(selected)* |
| [Option B] | [pros] | [cons] | [reason rejected] |
| [Option C] | [pros] | [cons] | [reason rejected] |

---

## Consequences

**Positive:**
- [Benefit 1]
- [Benefit 2]

**Negative / Trade-offs:**
- [Trade-off 1 — accepted because: reason]

---

## References

- [Link to relevant documentation, issue, or article]

---

*This ADR was drafted by Claude as part of the repository documentation process.*

---

# How to Add More ADRs

Copy this file and name it `ADR-NNN-short-title.md` where NNN is the next number.
Keep ADRs short — one decision per file, one page maximum.

**ADR Status values:**
- `Proposed` — under discussion, not yet decided
- `Accepted` — decision made and in effect
- `Deprecated` — was accepted but no longer applies
- `Superseded by ADR-NNN` — replaced by a later decision
