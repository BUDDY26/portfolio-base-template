# Changelog — {{PROJECT_NAME}}

All notable changes to this project are documented here.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
Versioning: [Semantic Versioning](https://semver.org/spec/v2.0.0.html)

---

## [Unreleased]

### Added
- Initial project structure from portfolio-base template
- CLAUDE.md repository memory file
- `.claude/skills/` — entry protocol, code review, refactor playbook, documentation, QA checklist, release procedure
- `.claude/hooks/` — post-edit-format, pre-delete-guard, test-on-core-change, block-sensitive-dirs
- GitHub Actions CI pipeline (lint + test + security scan)
- Dependabot configuration for automated dependency updates
- PR template and issue templates
- `scripts/bootstrap.sh` — interactive first-time setup
- `scripts/validate-structure.sh` — structure conformance checker
- docs/architecture.md, docs/adr/, docs/qa/, docs/runbooks/ templates

---

<!-- 
How to add entries:

## [1.0.0] - YYYY-MM-DD

### Added
- New features

### Changed
- Changes to existing functionality

### Deprecated
- Features that will be removed in a future release

### Removed
- Features removed in this release

### Fixed
- Bug fixes

### Security
- Security fixes
-->
