"""
{{PROJECT_NAME}}

{{PROJECT_DESCRIPTION}}

This package contains the application source code.
See docs/architecture.md for the full system design.
"""

__version__ = "0.1.0"
