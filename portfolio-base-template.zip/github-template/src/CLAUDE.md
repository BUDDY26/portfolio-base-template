# CLAUDE.md — src/ Module Guide

> Read this before modifying any file in `src/`.
> This file provides module-level sharp-edge warnings that Claude must see
> before working in this directory.

---

## What Lives Here

`{{PROJECT_NAME}}` application source code.

[Replace: describe the top-level structure of src/ once populated]

---

## Sharp Edges

<!-- Fill in after running the entry protocol. Examples: -->
- [Replace: e.g., `auth/` — token validation is tightly coupled to legacy session model. Do not refactor without approval.]
- [Replace: e.g., `database.py` — connection pooling logic is non-obvious. Read inline comments before changing anything.]
- [Replace: e.g., `config.py` — loaded at import time. Changes here affect the entire application startup sequence.]

---

## Protected Subdirectories

The following subdirectories require explicit approval in CLAUDE.md before
any modification. The `block-sensitive-dirs` hook will halt automatically.

- `auth/` — authentication and authorization logic
- `billing/` — payment processing (if present)
- *(add others as the project grows)*

---

## Coding Conventions in This Directory

- [Replace: e.g., All public functions must have type annotations]
- [Replace: e.g., All database queries must be parameterized — no f-string SQL]
- [Replace: e.g., Use dependency injection — no hardcoded instantiation inside functions]
- [Replace: e.g., Raise specific exceptions, never bare `except Exception`]

---

*Part of the Portfolio Repository Automation System*
