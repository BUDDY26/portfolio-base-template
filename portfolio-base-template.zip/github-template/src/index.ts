/**
 * Module: index
 *
 * Purpose:
 *   Application entry point for {{PROJECT_NAME}}.
 *   Replace this file with your actual entry point.
 *
 * Usage:
 *   npx ts-node src/index.ts
 *   npm run start
 */

/**
 * Application entry point.
 *
 * @returns Exit code — 0 for success, non-zero for failure.
 *
 * @example
 * const code = main();
 * process.exit(code);
 */
function main(): number {
  console.log(`{{PROJECT_NAME}} starting...`);
  // TODO: Replace with actual application startup
  return 0;
}

// Only run when executed directly, not when imported in tests
if (require.main === module) {
  process.exit(main());
}

export { main };
