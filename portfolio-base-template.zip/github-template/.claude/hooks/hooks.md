# .claude/hooks/hooks.md
# Claude Code Hook Definitions
#
# These hooks define automatic behaviors that trigger during Claude Code sessions.
# They act as guardrails — behaviors that run consistently regardless of prompt context.
# Claude should read this file during the entry protocol and respect all hooks.

---

## Hook: post-edit-format

**Trigger:** After Claude edits any `.py`, `.ts`, `.js`, `.tsx`, `.jsx` file  
**Action:** Remind Claude to suggest running the project formatter before considering the task complete  
**Command (Python):** `ruff check src/ && black src/` (or project-specific formatter)  
**Command (Node/TS):** `npx eslint . && npx prettier --write .`  
**Note:** Do not run automatically — suggest it and wait for user to execute

---

## Hook: pre-delete-guard

**Trigger:** Before Claude proposes deleting any file  
**Action:** HALT. State the file name and reason for deletion. Ask for explicit confirmation.  
**Format:** "⚠️ Delete Guard: I am about to delete `[filename]`. Reason: [reason]. Do you confirm? (yes/no)"  
**Never bypass this hook.**

---

## Hook: test-on-core-change

**Trigger:** After Claude edits any file inside `src/`  
**Action:** At the end of the response, append a reminder:
```
🧪 Test Reminder: Core source was modified. Consider running:
[test command from CLAUDE.md]
```

---

## Hook: block-sensitive-dirs

**Trigger:** When Claude is about to read or edit files in these directories:
- `src/auth/`
- `src/authentication/`
- `src/billing/`
- `src/payments/`
- `migrations/`
- `infra/`
- `infrastructure/`
- `.github/workflows/` (CI/CD)

**Action:** HALT before making any modification. State:
```
🔒 Sensitive Directory Guard: The file `[path]` is in a protected directory.
Modifications here require explicit approval. 
Reason this is protected: [auth/billing/migration/infra]
Do you want me to proceed? Please confirm explicitly.
```
Reading (not modifying) these files is permitted without this prompt.

---

## Hook: no-secrets-in-code

**Trigger:** Before Claude writes any code that includes string values that look like:
- API keys (long alphanumeric strings)
- Passwords or tokens
- Connection strings with credentials

**Action:** Replace with environment variable pattern instead. Example:
```python
# ❌ Never write this:
api_key = "sk-abc123xyz789"

# ✅ Always write this:
api_key = os.environ.get("API_KEY")
```
Flag this to the user and confirm the env variable name to use.

---

## Hook: proposal-before-refactor

**Trigger:** Whenever Claude is about to rename files, move directories, or change function signatures  
**Action:** Stop and write a proposal first. Do not execute until approved.  
**Format:** Use the Refactor Playbook proposal format from `.claude/skills/refactor-playbook.md`
