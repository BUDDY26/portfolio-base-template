---
name: release-procedure
description: >
  Executes a structured pre-release checklist before tagging a version.
  Use this skill when the user says 'prepare a release', 'tag a version',
  'release checklist', 'ready to release', 'cut a release', or 'what do I
  need to do before releasing'. Do NOT commit, tag, or push anything —
  only verify and report. All git operations require explicit user action.
---

# Release Procedure

## Overview
Runs a structured pre-release checklist to verify the codebase is clean,
documented, and safe to tag. Produces a release readiness report. Never
executes git commands — only audits and reports.

---

## Workflow

### Step 1 — Read CLAUDE.md
Confirm the project name, version strategy, and any release-specific rules noted there.

### Step 2 — Code Quality Check
1. Confirm no `print()` / `console.log()` debug statements remain in `src/`.
2. Confirm no TODO comments indicate broken or incomplete functionality.
3. Confirm no commented-out code blocks were accidentally left in.
4. Confirm `.env` values are not hardcoded anywhere.

### Step 3 — Test Suite Check
1. Note the test command from CLAUDE.md.
2. Ask: "Have all tests been run and passed locally?" — do not assume.
3. Check whether `tests/` contains tests for all recently changed modules.
4. Flag any test files that appear to be empty stubs.

### Step 4 — Documentation Check
- [ ] `README.md` reflects the current state of the project
- [ ] `CLAUDE.md` has been updated after the last session
- [ ] `docs/architecture.md` is not marked as "Draft" unless intentional
- [ ] At least one ADR exists in `docs/adr/`
- [ ] `docs/runbooks/operations.md` has accurate setup instructions
- [ ] `CHANGELOG.md` exists and has an entry for this release (if applicable)

### Step 5 — Dependency Check
1. Confirm `requirements.txt` or `package.json` is up to date.
2. Flag any dependencies pinned to an exact version without a comment explaining why.
3. Note whether a lock file is present.

### Step 6 — .env.example Check
Confirm `.env.example` lists every variable that the application actually uses.
Flag any variable used in source code that is missing from `.env.example`.

### Step 7 — Portfolio Check
1. Confirm the commit history is clean and professional (no "wip", "asdf", "fix fix fix" messages in recent commits).
2. Confirm the README would make sense to a technical reviewer seeing the project for the first time.

### Step 8 — Generate Release Report

```
## Release Readiness Report: {{PROJECT_NAME}}
**Date:** [today]
**Proposed version:** [e.g., v1.0.0]

### ✅ Passed
- [item]

### ⚠️ Warnings (should fix before release)
- [item]

### ❌ Blockers (must fix before release)
- [item]

### Release Verdict
[READY / NOT READY — one sentence explanation]

### Suggested git commands (execute manually after fixing blockers)
git add .
git commit -m "chore: prepare release v[VERSION]"
git tag -a v[VERSION] -m "Release v[VERSION]"
git push origin main --tags
```

---

## Rules
- Never run git commands — only audit and report.
- Never create a CHANGELOG entry — only flag if one is missing.
- If blockers exist, clearly state the release is NOT READY.
