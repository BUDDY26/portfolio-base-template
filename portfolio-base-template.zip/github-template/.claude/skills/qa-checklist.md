---
name: qa-checklist
description: >
  Runs a structured quality assurance checklist on a repository or file.
  Use this skill when the user says 'run QA', 'quality check this', 'audit
  the tests', 'check test coverage', 'write a QA plan', 'verify this is
  production ready', or 'what tests are missing'. Also use when preparing
  a repository for portfolio or employer review.
---

# QA Checklist Skill

## Overview
Performs a structured quality audit of a repository, evaluating code quality,
test coverage, documentation completeness, and portfolio readiness. Produces
an actionable report with prioritized gaps.

---

## Workflow

### Section 1 — Test Coverage Audit
1. Locate all test files.
2. Count total test files and total test functions/methods.
3. List source files that have NO corresponding test file.
4. Check for test patterns: unit tests, integration tests, end-to-end tests.
5. Check if a test runner is configured (pytest.ini, jest.config.js, etc.).
6. Rate coverage: None / Minimal (<20%) / Partial (20–60%) / Good (60–80%) / Comprehensive (80%+)

### Section 2 — Documentation Audit
1. Check existence and quality of:
   - [ ] `README.md` — present and complete?
   - [ ] `CLAUDE.md` — present and filled in?
   - [ ] `docs/architecture.md` — present?
   - [ ] `docs/adr/` — any decisions documented?
   - [ ] Inline docstrings on public functions?
   - [ ] Module-level docstrings?
2. Rate documentation: None / Minimal / Partial / Good / Comprehensive

### Section 3 — Code Quality Audit
1. Check for:
   - [ ] Consistent naming conventions
   - [ ] Functions under 30 lines (flag outliers)
   - [ ] No hardcoded secrets or credentials
   - [ ] No commented-out code blocks
   - [ ] No unresolved TODOs that indicate broken functionality
   - [ ] No `print()` / `console.log()` debug statements in production paths
2. Check for `.gitignore` presence and quality.
3. Check for linter/formatter configuration (`pyproject.toml`, `.eslintrc`, etc.).

### Section 4 — Repository Structure Audit
1. Verify the standard structure exists:
   - [ ] `src/` or equivalent source directory
   - [ ] `tests/`
   - [ ] `docs/`
   - [ ] `scripts/` (if automation scripts exist)
   - [ ] `.claude/skills/` and `.claude/hooks/`
2. Check for anti-patterns:
   - Test files mixed in with source files
   - Multiple `requirements.txt` in different directories with no explanation
   - Configuration files scattered across root

### Section 5 — Portfolio Readiness Audit
1. Evaluate as a third-party reviewer (employer or admissions committee):
   - [ ] Purpose is clear from README alone
   - [ ] Setup instructions are complete and would work on a fresh machine
   - [ ] Key technical decisions are documented
   - [ ] Code demonstrates professional practices
   - [ ] No embarrassing content (debug prints, TODO: fix this hack, etc.)
   - [ ] Commit history is clean (check `.git/` if accessible)

---

## Output Format

```
## QA Report: [repository name]
**Date:** [today]  
**Reviewed by:** Claude

---

### Test Coverage
**Rating:** [None / Minimal / Partial / Good / Comprehensive]

Tested files:
- [file]: [test file]

Untested files (no corresponding test):
- [file]
- [file]

Test configuration: [present / missing]

---

### Documentation
**Rating:** [None / Minimal / Partial / Good / Comprehensive]

| Document | Status | Notes |
|----------|--------|-------|
| README.md | ✅ / ❌ / ⚠️ | [notes] |
| CLAUDE.md | ✅ / ❌ / ⚠️ | |
| Architecture doc | ✅ / ❌ / ⚠️ | |
| ADRs | ✅ / ❌ / ⚠️ | |
| Docstrings | ✅ / ❌ / ⚠️ | |

---

### Code Quality
| Check | Status | Notes |
|-------|--------|-------|
| Naming conventions | ✅ / ❌ / ⚠️ | |
| Function length | ✅ / ❌ / ⚠️ | |
| No hardcoded secrets | ✅ / ❌ / ⚠️ | |
| No debug prints | ✅ / ❌ / ⚠️ | |
| Linter configured | ✅ / ❌ / ⚠️ | |

---

### Repository Structure
| Check | Status |
|-------|--------|
| src/ present | ✅ / ❌ |
| tests/ present | ✅ / ❌ |
| docs/ present | ✅ / ❌ |
| .claude/ present | ✅ / ❌ |
| .gitignore present | ✅ / ❌ |

---

### Portfolio Readiness
**Overall Score:** [X / 10]

**Ready for:** [Portfolio only / Entry-level employer / Senior employer / Graduate admissions]

**Blocking Issues (must fix before sharing):**
1. [issue]

**High Priority:**
1. [issue]

**Nice to Have:**
1. [suggestion]

---

### Recommended Actions (in order)
1. [action] — [estimated effort: 5 min / 30 min / 2 hr]
2. [action] — [estimated effort]
3. [action] — [estimated effort]
```
