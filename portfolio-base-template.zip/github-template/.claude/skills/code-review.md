---
name: code-review
description: >
  Performs a structured code review of files or functions. Use this skill when
  the user says 'review this code', 'check this file', 'audit this function',
  'give me a code review', 'what's wrong with this', or 'review PR changes'.
  Do NOT use for documentation-only files, config files, or YAML/JSON data files.
---

# Code Review Skill

## Overview
Performs a structured review of source code files, evaluating readability,
correctness, testability, and security. Produces a written report with
severity-labeled findings and actionable recommendations.

---

## Workflow

1. Read the file(s) to be reviewed in full.
2. Identify the language and apply language-appropriate standards.
3. Evaluate each of the following dimensions and record findings:

### Dimension 1 — Correctness
- Are there logic errors or off-by-one mistakes?
- Are edge cases (null, empty, zero, negative) handled?
- Are error conditions properly caught and surfaced?

### Dimension 2 — Readability
- Are names (variables, functions, classes) descriptive and consistent?
- Are functions short enough to understand in one reading (target: under 30 lines)?
- Is there dead code, commented-out code, or TODO items that should be resolved?

### Dimension 3 — Security
- Is user input sanitized before use?
- Are secrets or credentials hardcoded?
- Are authentication/authorization checks present where required?
- Are SQL queries parameterized (no string concatenation into queries)?

### Dimension 4 — Testability
- Are functions pure (same input → same output) where possible?
- Are dependencies injected rather than hardcoded?
- Does this code have existing test coverage?

### Dimension 5 — Documentation
- Do public functions have docstrings or JSDoc comments?
- Is complex logic explained with inline comments?
- Is the module-level purpose documented?

4. Write the review report using the output format below.
5. List items by severity: Critical → High → Medium → Low → Suggestion.
6. For each finding, include the specific line number or function name.

---

## Output Format

```
## Code Review: [filename]
**Reviewed by:** Claude  
**Date:** [today's date]  
**Language:** [language]  
**Lines reviewed:** [count]

---

### Summary
[2–3 sentences: overall impression, primary concerns, and whether this code
is ready to ship as-is]

---

### Findings

#### 🔴 Critical
- **[Line X — function_name]:** [description of issue and why it matters]
  > Recommendation: [specific fix]

#### 🟠 High
- **[Line X]:** [issue]
  > Recommendation: [fix]

#### 🟡 Medium
- **[Line X]:** [issue]
  > Recommendation: [fix]

#### 🟢 Low / Suggestion
- **[Line X]:** [improvement suggestion]

---

### Positive Observations
- [What the code does well — always include at least one]

---

### Recommended Next Steps
1. [Most important fix]
2. [Second most important]
3. [Optional improvement]
```

---

## Edge Cases

**If the file is over 500 lines:** Review the first 200 lines and the most
complex functions. Note that a full review requires multiple passes.

**If the file has no existing tests:** Always add a High finding:
"No test coverage detected. This code cannot be safely refactored without tests."

**If the code is intentionally obfuscated or minified:** Decline to review and
ask for the source version.
