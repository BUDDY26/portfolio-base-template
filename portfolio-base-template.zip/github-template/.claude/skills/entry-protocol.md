---
name: entry-protocol
description: >
  The mandatory repository entry protocol. Activates automatically when Claude Code
  enters a repository for the first time in a session, or when the user says
  'run entry protocol', 'scan this repo', 'understand this project', 'map this
  repository', 'analyze this codebase', or 'start fresh on this project'.
  Do NOT skip any phase. Do NOT modify any code or files during this protocol.
  This skill is also the prerequisite check before using refactor-playbook or
  any destructive skill.
---

# Repository Entry Protocol

## Overview

This skill defines the mandatory sequence Claude must follow when first entering
a repository. Its purpose is to prevent premature code changes by ensuring Claude
builds a complete mental model of the system before proposing or executing any
modifications. All phases are read-only. No file writes occur during this protocol.

---

## Phase 1 — Scan the Repository Structure

1. List the root directory contents using `ls -la` or equivalent.
2. Run `find . -type f | grep -v ".git" | sort` to see all files.
3. If `tree` is available, run `tree -L 3 --gitignore` for a visual map.
4. Read the root `CLAUDE.md` if it exists. If it does not exist, note this — it must be created as a first action after protocol completion.
5. Read `README.md` if it exists.
6. Record: total file count, directory depth, and overall size impression (tiny / small / medium / large).

---

## Phase 2 — Identify Languages and Frameworks

1. Scan all file extensions present and group them by type (`.py`, `.ts`, `.js`, `.go`, `.java`, `.yaml`, `.json`, etc.).
2. Look for language-specific config files:
   - Python: `pyproject.toml`, `setup.py`, `requirements.txt`, `Pipfile`
   - Node: `package.json`, `tsconfig.json`
   - Go: `go.mod`
   - Java: `pom.xml`, `build.gradle`
   - Rust: `Cargo.toml`
3. Look for framework indicators:
   - `fastapi`, `flask`, `django` → Python web
   - `react`, `next`, `vue` → frontend
   - `express`, `nestjs` → Node backend
   - `pytest`, `jest`, `mocha` → test framework
4. Record the primary language, secondary languages, and identified frameworks.

---

## Phase 3 — Locate Entry Points

1. Search for common entry point patterns:
   - `main.py`, `app.py`, `server.py`, `run.py`
   - `index.ts`, `index.js`, `server.ts`
   - `main.go`, `main.rs`
   - `App.tsx`, `App.jsx`
2. Read the `scripts` section of `package.json` if present.
3. Check for `Makefile` or `justfile` — read it if present.
4. Check `Dockerfile` or `docker-compose.yml` for `CMD` or `ENTRYPOINT` values.
5. Record: the primary entry point, secondary entry points (CLI, workers, etc.).

---

## Phase 4 — Locate Configuration Files

1. Scan for all configuration files:
   - `.env.example`, `.env.template`, `.env.sample`
   - `config/`, `settings/`, `conf/` directories
   - `*.yaml`, `*.yml`, `*.toml`, `*.ini`, `*.cfg` in root or config dirs
2. Read each configuration file (skip actual `.env` files — they may contain secrets).
3. Note all configurable values: database URLs, API keys (keys only, not values), feature flags, environment modes.
4. Record: list of config files and their purposes.

---

## Phase 5 — Map Dependencies

1. Read the dependency file for the primary language:
   - Python: `requirements.txt` or `pyproject.toml [tool.poetry.dependencies]`
   - Node: `package.json dependencies` and `devDependencies`
   - Go: `go.mod require` block
2. Categorize dependencies as: core runtime / development / testing / build tools.
3. Flag any dependencies that are outdated, unusual, or security-sensitive.
4. Check for a `lock` file (`poetry.lock`, `package-lock.json`, `yarn.lock`) — note if present.
5. Record: dependency count, key runtime packages, test framework.

---

## Phase 6 — Read Existing Tests

1. Locate the test directory (`tests/`, `test/`, `spec/`, `__tests__/`).
2. List all test files.
3. Read 2–3 test files to understand the testing patterns used.
4. Note: what is being tested, what is not being tested, what test runner is used.
5. Record: test file count, approximate coverage impression, test runner command.

---

## Phase 7 — Read Source Code (Selective)

1. Identify the 3–5 most important source files based on size and naming.
2. Read each file fully if under 200 lines; read the first 80 lines if longer.
3. Look for: class/function structure, naming conventions, comment quality, imports.
4. Note any code smells, TODOs, deprecated patterns, or obvious bugs.
5. Do NOT form refactoring plans yet — only observe and record.

---

## Phase 8 — Summarize the System

After completing Phases 1–7, write a structured summary using this exact format:

```
## Repository Summary

**Project Name:** [name]
**Primary Language:** [language + version if detectable]
**Frameworks:** [list]
**Entry Point:** [file path]
**Test Runner:** [command]
**Dependency Count:** [number] runtime / [number] dev

**Architecture in One Sentence:**
[Describe what this system does and how it's structured]

**Directory Structure:**
[Paste the tree output or a simplified version]

**Key Files:**
- [file]: [purpose]
- [file]: [purpose]
- [file]: [purpose]

**Configuration:**
- [config file]: [purpose]

**Test Coverage Impression:** [None / Minimal / Partial / Good / Comprehensive]

**Code Quality Impression:** [1–5 scale with one sentence of justification]

**Issues Noticed (do not fix yet):**
- [observation 1]
- [observation 2]

**Missing Files (should be created):**
- [ ] CLAUDE.md (if not present)
- [ ] README.md (if not present)
- [ ] docs/architecture.md
- [ ] tests/ directory (if no tests exist)
```

---

## Phase 9 — Propose Changes (Do Not Execute)

1. Based on the summary, generate a prioritized change proposal using this format:

```
## Proposed Changes

### Priority 1 — Documentation (Safe, no functional impact)
- [ ] [action]: [file or directory]

### Priority 2 — Organization (Low risk, structural only)
- [ ] [action]: [file or directory]

### Priority 3 — Quality (Moderate — requires review)
- [ ] [action]: [file or directory]

### Priority 4 — Functionality (High — requires explicit approval)
- [ ] [action]: [file or directory]

### Will NOT Touch (Protected)
- [file or pattern]: [reason]
```

2. Present this proposal to the user.
3. **Wait for explicit approval before executing any item on this list.**
4. Do not begin any action until the user confirms with a phrase such as:
   "Proceed with Priority 1", "Execute all", or "Start with [specific item]".

---

## Completion Checklist

Before exiting this protocol, confirm:

- [ ] Root directory scanned
- [ ] Languages and frameworks identified
- [ ] Entry points located
- [ ] Configuration files read
- [ ] Dependencies mapped
- [ ] Tests reviewed
- [ ] Source code surveyed (top files)
- [ ] System summary written
- [ ] Change proposal presented
- [ ] User approval received before any action

---

## Edge Cases

**If CLAUDE.md is missing:**
Add "Create CLAUDE.md from template" as the first item in Priority 1.

**If there are no tests:**
Note prominently in the summary. Add "Create tests/ directory with placeholder test structure" to Priority 1.

**If the repo is very large (500+ files):**
Limit Phase 7 to the top 5 files only. Note that a full audit may require multiple sessions.

**If the repo has no README:**
Flag this as the highest priority documentation item.

**If sensitive directories are found (`auth/`, `billing/`, `payments/`, `migrations/`):**
Add them to the "Will NOT Touch" section automatically and note: "Requires explicit approval before any modification."
