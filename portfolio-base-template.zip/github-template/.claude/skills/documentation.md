---
name: documentation
description: >
  Generates or improves documentation for source code and repositories.
  Use this skill when the user says 'document this', 'write a README',
  'add docstrings', 'write the architecture doc', 'explain this module',
  'generate API docs', 'add comments to this code', or 'write a runbook'.
  Do NOT modify any code logic — only add or improve documentation text.
---

# Documentation Skill

## Overview
Generates high-quality, technically accurate documentation for source code,
modules, APIs, and repositories. All output is written for a technical audience
(engineers, graduate admissions reviewers, employers).

---

## Workflow by Documentation Type

### Type A — Module / File Docstring
1. Read the entire file.
2. Identify: purpose, inputs, outputs, key dependencies.
3. Write a module-level docstring following the format below.
4. Add function-level docstrings to all public functions without them.

**Module Docstring Format (Python):**
```python
"""
Module: [module_name]

Purpose:
    [1–2 sentences describing what this module does and why it exists]

Key Components:
    - [ClassName or function_name]: [one-line description]

Usage:
    [Minimal code example showing how to import and use this module]

Dependencies:
    - [package]: [why it's needed]
"""
```

**Function Docstring Format (Python):**
```python
def function_name(param1: type, param2: type) -> return_type:
    """
    [One sentence: what this function does]

    Args:
        param1 (type): [description]
        param2 (type): [description]

    Returns:
        type: [description of return value]

    Raises:
        ExceptionType: [when this is raised]

    Example:
        >>> result = function_name(value1, value2)
        >>> print(result)
        [expected output]
    """
```

---

### Type B — README.md
Write a README using this structure:

```markdown
# [Project Name]

> [One-sentence description of what this project does]

## Overview
[2–3 paragraph description: what the project does, why it was built,
who would use it, and what problem it solves]

## Features
- [Feature 1]
- [Feature 2]
- [Feature 3]

## Tech Stack
| Layer | Technology |
|-------|-----------|
| [layer] | [tech + version] |

## Getting Started

### Prerequisites
- [requirement 1]
- [requirement 2]

### Installation
```bash
# Clone the repository
git clone [url]

# Install dependencies
[install command]

# Configure environment
cp .env.example .env
# Edit .env with your values
```

### Running the Application
```bash
[run command]
```

### Running Tests
```bash
[test command]
```

## Project Structure
```
[simplified tree]
```

## Architecture
[Brief description. Reference docs/architecture.md for full details.]

## Contributing
[If applicable]

## License
[License type]
```

---

### Type C — Architecture Document
Write `docs/architecture.md` using this structure:

```markdown
# Architecture Overview — [Project Name]

## System Purpose
[What does this system do? Who uses it?]

## Architecture Diagram (Text)
[ASCII or Mermaid diagram of components and their relationships]

## Component Breakdown
### [Component 1]
- **Location:** [directory/file]
- **Responsibility:** [what it does]
- **Interfaces:** [what it consumes/produces]

## Data Flow
[Step-by-step description of a typical request/transaction through the system]

## Key Technical Decisions
[Reference to docs/adr/ for formal decisions]

## External Dependencies
| Service | Purpose | Criticality |
|---------|---------|-------------|

## Known Limitations
- [limitation 1]

## Future Considerations
- [future work 1]
```

---

### Type D — ADR (Architecture Decision Record)
Write to `docs/adr/NNN-decision-title.md`:

```markdown
# ADR-[NNN]: [Decision Title]

**Date:** [YYYY-MM-DD]  
**Status:** [Proposed | Accepted | Deprecated | Superseded by ADR-NNN]  
**Deciders:** [Claude / developer name]

## Context
[What is the problem or situation that requires a decision?]

## Decision
[What was decided? State it clearly in one sentence.]

## Rationale
[Why was this decision made? What alternatives were considered?]

## Alternatives Considered
| Option | Pros | Cons |
|--------|------|------|

## Consequences
**Positive:**
- [benefit 1]

**Negative / Trade-offs:**
- [trade-off 1]

## References
- [relevant links or files]
```

---

## Output Rules

- Never alter code logic — documentation only.
- Match the existing code's style and conventions.
- If a docstring already exists, improve it rather than replace it.
- For portfolio-facing docs (README, architecture), write for a technical reader
  who has never seen this project before.
