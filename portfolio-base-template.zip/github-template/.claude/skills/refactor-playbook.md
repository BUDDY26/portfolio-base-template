---
name: refactor-playbook
description: >
  Executes a safe, structured refactoring workflow. Use this skill when the user
  says 'refactor this', 'clean up this file', 'improve this code', 'reorganize
  this module', 'make this more readable', or 'restructure this function'.
  PREREQUISITE: Entry protocol must have been run first. Do NOT refactor files
  in auth/, billing/, migrations/, or infra/ without explicit written approval.
  Do NOT use for writing new features or changing business logic.
---

# Refactor Playbook

## Overview
Provides a safe, step-by-step workflow for refactoring existing code without
changing external behavior. Every change is reversible and incremental.

---

## Prerequisite Check

Before beginning:
1. Confirm the entry protocol has been completed for this repository.
2. Confirm the file to be refactored is NOT in a protected directory.
3. Confirm tests exist for the code being refactored, OR note that refactoring
   proceeds without safety net (warn the user explicitly).

---

## Workflow

### Step 1 — Read and Understand
1. Read the entire file to be refactored.
2. Identify what the code does (its contract/behavior).
3. Note any tests that cover this code.
4. Write a one-sentence behavior description: "This code does X when given Y."

### Step 2 — Identify Refactoring Targets
Scan for and list:
- Functions longer than 30 lines (extract candidates)
- Duplicated logic (DRY violations)
- Magic numbers or strings (extract to constants)
- Deeply nested conditionals (flatten or extract)
- Unclear variable/function names (rename candidates)
- Missing docstrings on public functions
- Dead code or commented-out blocks

### Step 3 — Propose Changes (Do Not Execute Yet)
Write a numbered proposal:
```
Refactoring Proposal for [filename]:
1. [Change type]: [what and where] — [why]
2. [Change type]: [what and where] — [why]
...
```
Present proposal. Wait for user to approve before proceeding.

### Step 4 — Execute One Change at a Time
For each approved change:
1. State: "Making change [N]: [description]"
2. Make the change.
3. Verify the code still reads correctly.
4. If tests exist: note which tests should be run to verify.
5. State: "Change [N] complete. Behavior preserved: [confirm yes/uncertain]."

### Step 5 — Final Review
After all changes:
1. Read the refactored file in full.
2. Confirm the one-sentence behavior description from Step 1 still holds.
3. List all changes made in a summary.
4. Note any tests that should now be run.

---

## Rules

- Never change behavior — only structure.
- Never combine multiple refactoring types in one step.
- If a change would alter a public API (function signature, return type), stop and request approval.
- If unsure whether behavior is preserved, say so explicitly.

---

## Output Format

```
## Refactoring Complete: [filename]

### Changes Made
1. [Change]: [brief description]
2. [Change]: [brief description]

### Behavior Preserved
[Confirm yes, or list any uncertain areas]

### Tests to Run
- [test command or file]

### Remaining Opportunities (not actioned)
- [optional improvement not yet addressed]
```
