"""
test_integration_example.py — Integration test placeholder.

Integration tests verify that components work correctly together.
Replace this file with tests for your actual integration points
(e.g., API endpoints + database, service + external API).

Run with: pytest tests/integration/ -v
"""

import pytest


class TestIntegrationExample:
    """
    Placeholder integration test class.
    Replace with real integration tests once your components exist.
    """

    @pytest.mark.skip(reason="Placeholder — replace with real integration test")
    def test_example_integration(self):
        """
        Template for an integration test.

        Pattern:
          1. Arrange: set up real (or test-double) dependencies
          2. Act: call the function/endpoint that crosses component boundaries
          3. Assert: verify the end-to-end result
        """
        pass


# ── Integration Test Guidelines ───────────────────────────────────────────────
#
# Integration tests should:
#   - Test real component interactions (not mocked internals)
#   - Use a test database or test container where possible
#   - Be slower than unit tests — that is acceptable
#   - Be clearly separated from unit tests in this directory
#
# See docs/qa/qa-plan.md for the full integration test strategy.
