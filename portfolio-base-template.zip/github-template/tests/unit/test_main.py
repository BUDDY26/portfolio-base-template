"""
test_main.py — Unit tests for src/main.py

Tests the application entry point.
Replace with tests for your actual source modules.

Run with: pytest tests/unit/test_main.py -v
"""

import sys
import os

# Ensure src/ is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.main import main


class TestMain:
    """Tests for the main entry point."""

    def test_main_returns_zero_on_success(self):
        """main() should return 0 (success exit code) when no errors occur."""
        result = main()
        assert result == 0, f"Expected exit code 0, got {result}"

    def test_main_returns_integer(self):
        """main() must always return an integer suitable for sys.exit()."""
        result = main()
        assert isinstance(result, int), f"Expected int, got {type(result)}"


# ── Template: How to write tests for this project ─────────────────────────────
#
# UNIT TEST PATTERN:
#
#   class TestMyModule:
#       def test_function_with_valid_input(self):
#           result = my_function(valid_input)
#           assert result == expected_value
#
#       def test_function_with_edge_case(self):
#           result = my_function(edge_case_input)
#           assert result == expected_edge_value
#
#       def test_function_raises_on_invalid_input(self):
#           with pytest.raises(ValueError):
#               my_function(invalid_input)
#
# See docs/qa/qa-plan.md for coverage targets and test strategy.
