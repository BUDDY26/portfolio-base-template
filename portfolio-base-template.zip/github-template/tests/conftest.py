"""
conftest.py — Pytest configuration and shared fixtures.

This file is loaded automatically by pytest before any tests run.
Place shared fixtures, hooks, and configuration here.

See docs/qa/qa-plan.md for the full test strategy.
"""

import pytest


# ── Example fixtures ──────────────────────────────────────────────────────────
# Replace or extend these with project-specific fixtures.

@pytest.fixture
def sample_data() -> dict:
    """
    Provides a minimal sample data dictionary for tests.

    Returns:
        dict: Sample data with predictable values for assertion.
    """
    return {
        "id": 1,
        "name": "test-item",
        "active": True,
    }


# ── Configuration ─────────────────────────────────────────────────────────────
# pytest configuration can also go in pyproject.toml [tool.pytest.ini_options]
# or pytest.ini — prefer pyproject.toml for new projects.
